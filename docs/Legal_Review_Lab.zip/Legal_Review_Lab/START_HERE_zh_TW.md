# NDA API 實測：一步步操作

目標：固定模型、prompt、政策和輸出設定，讓 15 份合成 NDA 各獨立呼叫三次，保留 45 次 API 回覆，再計分。舊的 agent 批次和新 API 實驗分開保存。

## 第一步：連接 API 帳戶

優先在 ChatGPT 安裝 OpenAI Developers 並完成帳戶連結。官方 quickstart 說明這個整合可協助 API 設定及建立 project API key。完成連結後再進行單份測試；此套件尚未完成 API 實跑。

不需要把金鑰貼在對話裡，也不要把金鑰放入 GitHub。若採用 Windows 本機執行，程式可在終端機隱藏輸入金鑰，或讀取已設定的 OPENAI_API_KEY 環境變數。

官方說明：https://developers.openai.com/api/docs/quickstart

若符合資格，可先到 ChatGPT 的 Settings → Billing 查看 API credits benefit；實際資格與額度以帳戶顯示為準。官方說明：https://developers.openai.com/api/docs/guides/chatgpt-api-credits

## 第二步：確認本機能執行 Python

把 ZIP 解壓縮，進入 Legal_Review_Lab 資料夾。在檔案總管的網址列輸入 powershell 並按 Enter。執行：

```powershell
python --version
```

若看到 Python 3.10 或更新版本，就可以繼續。若 Windows 開啟 Microsoft Store，或顯示找不到 Python，先停在這裡處理安裝；不要反覆執行付費 API 命令。

## 第三步：看測試計畫，不呼叫 API

```powershell
python scripts/api_study.py plan
```

檢查模型、reasoning、每次輸出上限、文件清單與預定 45 次請求。預設模型為 gpt-5.4-mini-2026-03-17，reasoning 為 low。Temperature 和 top_p 未傳入；紀錄會如實標示 omitted，不會捏造為 0。模型是否對妳的帳戶開放，仍以第一次 API 回覆為準。

官方模型說明：https://developers.openai.com/api/docs/models/gpt-5.4-mini

## 第四步：先做一份開發文件的連線測試

先閱讀 API_Study_Guide.md 的 smoke 命令。未加 --execute 只預覽計畫；加入 --execute 才會真的呼叫 API 並可能產生費用。先確認帳戶額度與預算，再執行一份開發 NDA。

回來查看：response ID、HTTP request ID（若回傳）、要求與實際回傳的模型、設定、usage、原始輸出和格式驗證。單份失敗時先看紀錄，不能把失敗項目略過後宣稱完整實驗完成。

## 第五步：單份成功後才執行 45 次

完整命令與 resume 行為見 API_Study_Guide.md。每份 NDA 的每次審閱都是新的 API 請求，不會把前一份合約或回覆串成聊天，也不會把標準答案放入請求。

三回合必須使用同一個凍結設定。若遇到模型不支援設定、拒絕、輸出截斷、模型版本不符或網路不確定結果，先停止；修正設定要開新 study，不能悄悄改同一個實驗。程式不會自動重試付費請求。

## 第六步：計分與作品集更新

45 份有效紀錄都齊全後，用 score 命令產生每回合 precision／recall、逐 issue 一致性及結果報告。保留原始結果，包括沒抓到或多抓的問題。先確認實際結果，再更新履歷和作品集；這個套件現在只代表執行流程已準備好。

若要讓我檢查，提供產出的 study 資料夾即可，不要附上金鑰或環境設定檔。
