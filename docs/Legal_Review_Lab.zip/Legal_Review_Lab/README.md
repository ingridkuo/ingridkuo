# Legal Review Lab

Ingrid Kao

Local browser/Python API prototype, repeated-generation evidence, scoring harness and SALI crosswalk.

Requires Python 3.10+. No dependency installation or API key is needed for local checks.

```sh
python3 scripts/web_lab.py
```

Open the loopback URL printed in the terminal; select **Run checks**. Stop with Ctrl+C.

```sh
python3 scripts/run_lab.py check --require-repeats --json
```

See [check explanations](Check_Guide.md), [one-page results](repeatability/Repeatability_Results.pdf), [SALI/DMS decisions](taxonomy/Taxonomy_and_DMS.md) and [technical scope](Technical_Scope.md).

The server validates preserved responses; it makes no new model calls. The three observed agent batches reviewed the same 15 synthetic NDAs. Model snapshot and sampling controls were not exposed. Source versions, reference labels and unmodified responses are included.

This standalone runtime package omits portfolio PDF-authoring tools and website assets. The full public portfolio contains the complete presentation build.
